/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTENEDOR;
import static CONTENEDOR.Gestion_Anuncios.AnunciosT;
import static CONTENEDOR.Planificador_Salidas.DestinosT;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author eber-
 * Aplicacion para gestionar monitores que visualizan las salidas de autobuses a distintos destinos
 * 
 */
public class ADMINISTRADOR_SYS extends javax.swing.JFrame{
    
    static ArrayList <Integer> clientesC = new ArrayList<>();//Lista de indice de monitores conectados al server
    static ArrayList <Integer> puerto = new ArrayList<>();//Puerto en el que se conectan
    static ArrayList <String> Instruc = new ArrayList<>();//Mensaje de monitores
    static ArrayList <InetAddress> address = new ArrayList<>();//Lista de direcciones IP de monitores
    static ArrayList <String> Destinos = new ArrayList<>();//Lista de Destinos de autobus
    static ArrayList <String> Hora = new ArrayList<>();//Lista de hora de salida
    static ArrayList <Integer> PuertaAb = new ArrayList<>();//Lista de las puertas de abordaje de Salidas
    static ArrayList <Integer> NumAnden = new ArrayList<>();//Lista de numero de anden de salidas
    static ArrayList <Integer> NumAutobus = new ArrayList<>();//Lista de los numeros de autobus de las salidas
    
    static String SalidasData="";//Datos codificados de salidas al monitor deseado
    static String AnunciosData="";//Datos codificados de anuncios en el monitor deseado
    
    static DatagramSocket unSocket;//Soket del servidor para recibir peticiones de monitores
    static DatagramPacket res;//Objeto para enviar Paquete de datos a monitores (clientes)
    static int numC=0;//numero de clientes conectados
    Planificador_Salidas planS = new Planificador_Salidas ();//Clase para gestionar las salidas
    Gestion_Anuncios GestAds= new Gestion_Anuncios();//Clase para gestionar los anuncios
    
    /**
     * Creates new form SERVER_INTERFACE
     */
    public ADMINISTRADOR_SYS() {
        initComponents();
        setLocationRelativeTo(null);
        incializaIDCliente();//Inicializa los arrays para datos de los monitores
        Thread t = new Thread(new Server());//Hilo del servidor para recibir peticiones de clientes
        t.start();//inicializa el server
        setIconImage(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ADMIN.png")).getImage());

    }
    //obtiene los destinos de la tabla en la clase planificador de salidas
    void CargaDestinos(){
        Destinos.clear();
        for(int a=0;a<cuentaFilas();a++){
            String d=DestinosT.getValueAt(a, 0).toString();
            Destinos.add(d);
        }
    }
    //obtiene los horarios de la tabla en la clase planificador de salidas
    void CargaHorarios(){
        Hora.clear();
        for(int a=0;a<cuentaFilas();a++){
            String h=DestinosT.getValueAt(a, 1).toString();
            Hora.add(h);
        }
    }
    //obtiene las puertas de abordaje de la tabla en la clase planificador de salidas
    void CargaPuertaAb(){
        PuertaAb.clear();
        for(int a=0;a<cuentaFilas();a++){
            String p=DestinosT.getValueAt(a, 2).toString();
            int ab = Integer.parseInt(p);
            PuertaAb.add(ab);
        }
    }
    //obtiene los numeros de anden de la tabla en la clase planificador de salidas
    void CargaAnden(){
        NumAnden.clear();
        for(int a=0;a<cuentaFilas();a++){
            String n=DestinosT.getValueAt(a, 3).toString();
            int an = Integer.parseInt(n);
            NumAnden.add(an);
        }
    }
    //obtiene los numeros de anden de la tabla en la clase planificador de salidas
    void CargaNumAutobus(){
        NumAutobus.clear();
        for(int a=0;a<cuentaFilas();a++){
            String n=DestinosT.getValueAt(a, 4).toString();
            int au = Integer.parseInt(n);
            NumAutobus.add(au);
        }
    }
    
    //Empaqueta los datos de las salidas con una estructura para enviarlos al monitor deseado
    //y que sean interpretados de forma adecuada
    void empaquetaSalidas(){
        SalidasData=null;
        String h="";
        for(int a=0;a<Destinos.size();a++){
            h+=Destinos.get(a)+"#";
            h+=Hora.get(a)+"#";
            h+=PuertaAb.get(a)+"#";
            h+=NumAnden.get(a)+"#";
            h+=NumAutobus.get(a);
            if(a+1<Destinos.size()){
                h+="&";
            }
        }
        SalidasData=h;
        System.out.println(""+SalidasData);
        System.out.println("Tamaño del paquete: "+h.getBytes().length);
    }
    //obtiene los anuncios de la tabla en la clase gestion de anuncios
    //y les aplica una estructura para posteriormente enviarlos a los monitores
    void empaquetaAnuncios(){
        AnunciosData=null;
        String h="";
        for(int a=0;a<AnunciosT.getRowCount();a++){
            h+=AnunciosT.getValueAt(a, 0);
            if(a+1<AnunciosT.getRowCount()){
                h+="&";
            }
        }
        AnunciosData=h;
        System.out.println(""+AnunciosData);
    }
    
    //empaqueta y prepara los datos para enviarlos al monitor seleccionado con un boton desde
    //la interfaz
    void preparaDatos(){
        CargaDestinos();
        CargaNumAutobus();
        CargaHorarios();
        CargaPuertaAb();
        CargaAnden();
        OrdenaSalidas();
        empaquetaSalidas();
        empaquetaAnuncios();
    }
    //Obtiene el numero de filas para determinar los datos a enviar sin considerar los  que estan vacios
    int cuentaFilas() {
        int row = 0;
        int a = 0;
        for (a = 0; a < DestinosT.getRowCount(); ++a) {

            try {
                if (!(DestinosT.getValueAt(a, 0).equals("")) && !(DestinosT.getValueAt(a, 1).equals(""))
                        && !(DestinosT.getValueAt(a, 2).equals("")) && !(DestinosT.getValueAt(a, 3).equals(""))
                        && !(DestinosT.getValueAt(a, 4).equals(""))) {
                    row++;
                }

            } catch (NullPointerException e) {
                return row;
            }

        }
        return row;
    }
    
    //Ordena las salidas segun la hora de salida de autobuses para que se interpreten de forma adecuada en
    //los monitores a los que se envien
    void OrdenaSalidas() {
        ArrayList <String> temp = new ArrayList <>();
        for (int i = 0; i < Hora.size(); i++) {
            for (int j = i + 1; j < Hora.size(); j++) {
                if (Hora.get(i).compareTo(Hora.get(j)) > 0) {
                    temp.clear();
                    temp.add(Destinos.get(j));
                    Destinos.set(j, Destinos.get(i));
                    Destinos.set(i, temp.get(0));
                    
                    temp.add(Hora.get(j));
                    Hora.set(j, Hora.get(i));
                    Hora.set(i, temp.get(1));
                    
                    temp.add(PuertaAb.get(j)+"");
                    PuertaAb.set(j, PuertaAb.get(i));
                    PuertaAb.set(i, Integer.parseInt(temp.get(2)));
                    
                    temp.add(NumAnden.get(j)+"");
                    NumAnden.set(j, NumAnden.get(i));
                    NumAnden.set(i, Integer.parseInt(temp.get(3)));
                    
                    temp.add(NumAutobus.get(j)+"");
                    NumAutobus.set(j, NumAutobus.get(i));
                    NumAutobus.set(i, Integer.parseInt(temp.get(4)));
                }
            }
        }
        for (int n = 0; n < Destinos.size(); n++) {
            DestinosT.setValueAt(Destinos.get(n), n, 0);
            DestinosT.setValueAt(Hora.get(n), n, 1);
            DestinosT.setValueAt(PuertaAb.get(n), n, 2);
            DestinosT.setValueAt(NumAnden.get(n), n, 3);
            DestinosT.setValueAt(NumAutobus.get(n), n, 4);
        }
    }
    
    //inicializa los arrays para los 4 monitores
    //indice de cliente, puerto y direccion ip
    private static int incializaIDCliente(){
        if(numC<4){
            for(int i =0;i<4;i++){
                clientesC.add(-1);
                puerto.add(-1);
                address.add(null);
            }
            
        }
        return 1;
    }
    
    //Desglosa la instruccion del monitor (Puede notificar una perdida de conexion)
    private static void DesglosaInst(String inst) {
        String Pal = "";
        Instruc.clear();
        for (int i = 0; i < inst.length(); i++) {
            if (inst.charAt(i) == '-') {
                Instruc.add(Pal);
                System.out.println("Palabra recibida: " + Pal);
                Pal = "";
            } else {
                Pal += inst.charAt(i);
            }
        }
        if(Instruc.isEmpty()){
            Instruc.add("none");
        }
        for (int i = 0; i < Instruc.size(); i++) {
            System.out.println("" + Instruc.get(i));
        }
    }
    
    //Asigna un id al cliente para controlar el monitor segun la lista en la que le corresponda
    private static int asignaIDCliente(){
        if(numC<4){
            for(int i =0;i<4;i++){
                if(clientesC.get(i)==-1){
                    clientesC.set(i, i+1);
                    numC++;
                    switch (i) {
                        case 0:
                            idT1.setText("Monitor 1");
                            eventos.append("\nMonitor 1 Listo para recibir Salidas y Anuncios");
                            break;
                        case 1:
                            idT2.setText("Monitor 2");
                            eventos.append("\nMonitor 2 Listo para recibir Salidas y Anuncios");
                            break;
                        case 2:
                            idT3.setText("Monitor 3");
                            eventos.append("\nMonitor 3 Listo para recibir Salidas y Anuncios");
                            break;
                        case 3:
                            idT4.setText("Monitor 4");
                            eventos.append("\nMonitor 4 Listo para recibir Salidas y Anuncios");
                            eventos.append("\nMONITORES LISTOS PARA OPERAR");
                            break;
                    }
                    return i+1;
                }
            }
        }else{
            eventos.append("\nTODOS LOS MONITORES ESTAN EN FUNCION, INTENTA MAS TARDE");
        }
        return -1;
    }
    
    //Cuando algun monitor notifica que se desconecto desde un paquete recibido,
    //limpia el espacio y lo pone disponible para que se vuelva a conectar el monitor
    private void limpiaEspacio(int ind){
        if(clientesC.get(ind)!=-1){
            clientesC.set(ind, -1);
            address.set(ind, null);
            puerto.set(ind, -1);
            switch (ind) {
                case 0:
                    idT1.setText("ID_PUERTA");
                    break;
                case 1:
                    idT2.setText("ID_PUERTA");
                    break;
                case 2:
                    idT3.setText("ID_PUERTA");
                    break;
                case 3:
                    idT4.setText("ID_PUERTA");
                    break;
            }
            numC--;
        }
    }
    
    //Coloca la peticion  de conexion del monitor donde encuentre el primer espacio disponible
    private static void enlistaCliente(int port, InetAddress direccion){
        for(int i=0;i<4;i++){
            if(puerto.get(i)==-1&&address.get(i)==null){
                puerto.set(i, port);
                address.set(i,direccion);
                break;
            }
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel7 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        idT1 = new javax.swing.JLabel();
        idT2 = new javax.swing.JLabel();
        idT3 = new javax.swing.JLabel();
        idT4 = new javax.swing.JLabel();
        etic2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        eventos = new javax.swing.JTextArea();
        jButton14 = new javax.swing.JButton();
        sendData1 = new javax.swing.JButton();
        sendData2 = new javax.swing.JButton();
        sendData3 = new javax.swing.JButton();
        sendData4 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        admnSalidas = new javax.swing.JButton();
        admnAnuncios = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel7.setFont(new java.awt.Font("Verdana", 0, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 51, 102));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("ADMINISTRADOR DE MONITORES");

        jLabel1.setFont(new java.awt.Font("Lato", 1, 18)); // NOI18N
        jLabel1.setText("VISUALIZADOR 1");

        jLabel2.setFont(new java.awt.Font("Lato", 1, 18)); // NOI18N
        jLabel2.setText("VISUALIZADOR 2");

        jLabel3.setFont(new java.awt.Font("Lato", 1, 18)); // NOI18N
        jLabel3.setText("VISUALIZADOR 3");

        idT1.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        idT1.setText("ID_PUERTA");

        idT2.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        idT2.setText("ID_PUERTA");

        idT3.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        idT3.setText("ID_PUERTA");

        idT4.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        idT4.setText("ID_PUERTA");

        etic2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        etic2.setForeground(new java.awt.Color(0, 51, 102));
        etic2.setText("ID_PUERTA");

        jScrollPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0), 3));

        eventos.setColumns(20);
        eventos.setRows(5);
        eventos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 51)));
        jScrollPane1.setViewportView(eventos);

        jButton14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton14.setForeground(new java.awt.Color(255, 102, 0));
        jButton14.setText("SALIR");
        jButton14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton14MouseClicked(evt);
            }
        });

        sendData1.setText("Enviar Datos");
        sendData1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sendData1MouseClicked(evt);
            }
        });

        sendData2.setText("Enviar Datos");
        sendData2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sendData2MouseClicked(evt);
            }
        });

        sendData3.setText("Enviar Datos");
        sendData3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sendData3MouseClicked(evt);
            }
        });

        sendData4.setText("Enviar Datos");
        sendData4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sendData4MouseClicked(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Lato", 1, 18)); // NOI18N
        jLabel4.setText("VISUALIZADOR 4");

        admnSalidas.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        admnSalidas.setText("ADMINISTRAR SALIDAS");
        admnSalidas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                admnSalidasMouseClicked(evt);
            }
        });

        admnAnuncios.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        admnAnuncios.setText("ADMINISTRAR ANUNCIOS");
        admnAnuncios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                admnAnunciosMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(admnSalidas)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(admnAnuncios))
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 341, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(idT1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(idT2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(idT3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(sendData1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(sendData2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(sendData3, javax.swing.GroupLayout.Alignment.TRAILING)))
                                        .addComponent(etic2)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(idT4, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(sendData4))))))
                        .addContainerGap(36, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(etic2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(idT1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(sendData1))
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(idT2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(sendData2))
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(idT3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(sendData3))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(idT4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sendData4))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(admnSalidas)
                    .addComponent(admnAnuncios))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addComponent(jButton14))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //Boton para enviar datos al monitor 1 (el que primero se ejecuto y se conecto con el server)
    private void sendData1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sendData1MouseClicked
        if(numC>0){
                int port = puerto.get(0);
                InetAddress host = address.get(0);
                preparaDatos();
                String code = "1" +"%"+SalidasData+"%"+AnunciosData+"%";
                res = new DatagramPacket(code.getBytes(), code.length(), host, port);
                try {
                    unSocket.send(res);
                    eventos.append("\nDatos enviados al Monitor 1");
                } catch (IOException ex) {
                    Logger.getLogger(ADMINISTRADOR_SYS.class.getName()).log(Level.SEVERE, null, ex);
                }
        }
    }//GEN-LAST:event_sendData1MouseClicked

    //Boton para enviar los datos al monitor 2 (el segundo que se ejecuto y se conecto con el server)
    private void sendData2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sendData2MouseClicked
        if(numC>0){
            int port = puerto.get(1);
                InetAddress host = address.get(1);
                preparaDatos();
                String code = "2" +"%"+SalidasData+"%"+AnunciosData+"%";
                res = new DatagramPacket(code.getBytes(), code.length(), host, port);
                try {
                    unSocket.send(res);
                    eventos.append("\nDatos enviados al Monitor 2");
                } catch (IOException ex) {
                    Logger.getLogger(ADMINISTRADOR_SYS.class.getName()).log(Level.SEVERE, null, ex);
                }
        }
    }//GEN-LAST:event_sendData2MouseClicked
    //Boton para enviar los datos al monitor 3 (el tercero que se ejecuto y se conecto con el server)
    private void sendData3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sendData3MouseClicked
        if(numC>0){
            int port = puerto.get(2);
                InetAddress host = address.get(2);
                preparaDatos();
                String code = "3" +"%"+SalidasData+"%"+AnunciosData+"%";
                res = new DatagramPacket(code.getBytes(), code.length(), host, port);
                try {
                    unSocket.send(res);
                    eventos.append("\nDatos enviados al Monitor 3");
                } catch (IOException ex) {
                    Logger.getLogger(ADMINISTRADOR_SYS.class.getName()).log(Level.SEVERE, null, ex);
                }
        }
    }//GEN-LAST:event_sendData3MouseClicked
    
    
    //Boton para cerrar la aplicacion
    private void jButton14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton14MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jButton14MouseClicked
    //Boton para enviar los datos al monitor 4 (el cuarto que se ejecuto y se conecto con el server)
    private void sendData4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sendData4MouseClicked
        if (numC > 0) {
            int port = puerto.get(3);
                InetAddress host = address.get(3);
                preparaDatos();
                String code = "4" +"%"+SalidasData+"%"+AnunciosData+"%";
                res = new DatagramPacket(code.getBytes(), code.length(), host, port);
                try {
                    unSocket.send(res);
                    eventos.append("\nDatos enviados al Monitor 4");
                } catch (IOException ex) {
                    Logger.getLogger(ADMINISTRADOR_SYS.class.getName()).log(Level.SEVERE, null, ex);
                }
        }
    }//GEN-LAST:event_sendData4MouseClicked
    //boton para visualizar y gestionar la tabla del planificador de salidas
    private void admnSalidasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_admnSalidasMouseClicked
        planS.setVisible(true);
    }//GEN-LAST:event_admnSalidasMouseClicked
    //boton para visualizar y gestionar la tabla de anuncios
    private void admnAnunciosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_admnAnunciosMouseClicked
        GestAds.setVisible(true);
    }//GEN-LAST:event_admnAnunciosMouseClicked

    //El hilo server permite recibir peticiones de conexion o desconexion de los monitores
    class Server implements Runnable {

        public Server() {
        }

        @Override
        public void run() {
            try {
                unSocket = new DatagramSocket(6789); //puerto en el que escucha las peticiones de los monitores
                eventos.append("\n\t---SERVIDOR INICIALIZADO---");
                incializaIDCliente();//inicializa los arrays para que cuando reciba una peticion  de un cliente, lo coloque en el id correspondiente
                while (true) {
                    //Se mantiene esperando peticiones de los monitores
                    byte[] bufer = new byte[1000];
                    DatagramPacket peticion = new DatagramPacket(bufer, bufer.length);
                    eventos.append("\nEsperando a un Monitor");
                    //recibe la peticion del cliente
                    unSocket.receive(peticion);
                    
                    String rv = new String(peticion.getData()).trim();
                    System.out.println("recibo: " + rv);
                    //Desglosa las instrucciones
                    DesglosaInst(rv);
                    //si la instruccion en la posicion 0 es  diferente de end, lo que hara, es enlistar el monitor en la interfaz
                    if (!Instruc.get(0).equals("end")) {
                        eventos.append("\nRECIBO: " + rv);
                        eventos.append("\nLa peticion proviene de: " + peticion.getAddress() + "\nEn el puerto: " + peticion.getPort());
                        InetAddress addres = peticion.getAddress();
                        int puerto = peticion.getPort();
                        eventos.append("\nMonitor esperando una Respuesta");
                        enlistaCliente(puerto, addres);
                        asignaIDCliente();
                    } else {//en caso de que sea end, lo que hara, es liberar el espacio que administraba dicho monitor segun su id
                        int id = Integer.parseInt(Instruc.get(1));
                        eventos.append("\nFINALIZA EL PROCESO DE LA TAREA_" + id);
                        limpiaEspacio(id - 1);
                    }
                }
                //manejo de posibles excepciones
            } catch (SocketException e) {
                System.out.println("Socket: " + e.getMessage());
            } catch (IOException e) {
                System.out.println("IO: " + e.getMessage());
            }
        }
    }
 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ADMINISTRADOR_SYS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new ADMINISTRADOR_SYS().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton admnAnuncios;
    private javax.swing.JButton admnSalidas;
    private javax.swing.JLabel etic2;
    private static javax.swing.JTextArea eventos;
    public static javax.swing.JLabel idT1;
    public static javax.swing.JLabel idT2;
    public static javax.swing.JLabel idT3;
    public static javax.swing.JLabel idT4;
    private javax.swing.JButton jButton14;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton sendData1;
    private javax.swing.JButton sendData2;
    private javax.swing.JButton sendData3;
    private javax.swing.JButton sendData4;
    // End of variables declaration//GEN-END:variables
}
